# -*- coding: utf-8 -*-
# Part of Browseinfo. See LICENSE file for full copyright and licensing details.

from . import product_template
from . import res_config_setting
from . import stock_move
from . import stock_quant
from . import stock_production_lot
